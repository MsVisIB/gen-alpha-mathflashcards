
let currentLevel = 0;
const container = document.getElementById('flashcards-container');
const levelTitle = document.getElementById('level-title');
const nextBtn = document.getElementById('nextLevelBtn');
const flipSound = document.getElementById('flipSound');
const confettiSound = document.getElementById('confettiSound');

function renderLevel(levelIndex) {
  container.innerHTML = '';
  const cards = flashcardLevels[levelIndex];
  levelTitle.innerText = 'Level ' + (levelIndex + 1);
  cards.forEach(({ front, back }) => {
    const card = document.createElement('div');
    card.className = 'card show-front';
    const frontDiv = document.createElement('div');
    frontDiv.className = 'front';
    frontDiv.innerText = front;
    const backDiv = document.createElement('div');
    backDiv.className = 'back';
    backDiv.innerText = back;
    card.appendChild(frontDiv);
    card.appendChild(backDiv);
    card.onclick = () => {
      card.classList.toggle('show-front');
      card.classList.toggle('show-back');
      flipSound.currentTime = 0;
      flipSound.play();
    };
    container.appendChild(card);
  });
}

nextBtn.onclick = () => {
  confettiSound.play();
  confetti({ particleCount: 200, spread: 70, origin: { y: 0.6 } });
  currentLevel = (currentLevel + 1) % flashcardLevels.length;
  renderLevel(currentLevel);
};

renderLevel(currentLevel);
