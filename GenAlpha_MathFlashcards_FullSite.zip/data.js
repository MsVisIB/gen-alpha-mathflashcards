const flashcardLevels = [
  [
    {
      "front": "Distributive property",
      "back": "a(b + c) = ab + ac."
    },
    {
      "front": "Pattern",
      "back": "A repeated or regular arrangement."
    },
    {
      "front": "Variable",
      "back": "A letter that stands for a number."
    },
    {
      "front": "Difference",
      "back": "The result of subtraction."
    },
    {
      "front": "Inverse operations",
      "back": "Operations that undo each other."
    },
    {
      "front": "Expression",
      "back": "A math phrase with numbers and operations."
    },
    {
      "front": "Order of operations",
      "back": "The correct sequence to solve math expressions."
    },
    {
      "front": "Product",
      "back": "The result of multiplication."
    },
    {
      "front": "Dividend",
      "back": "The number being divided."
    },
    {
      "front": "Associative property",
      "back": "Grouping doesn't change the answer in + or \u00c3\u2014."
    }
  ],
  [
    {
      "front": "Input/output table",
      "back": "A table showing how numbers change using a rule."
    },
    {
      "front": "Multiple",
      "back": "A number made by multiplying another number."
    },
    {
      "front": "Commutative property",
      "back": "Order doesn't change the answer in + or \u00c3\u2014."
    },
    {
      "front": "Remainder",
      "back": "The amount left over after division."
    },
    {
      "front": "Sum",
      "back": "The result of addition."
    },
    {
      "front": "Equation",
      "back": "A math sentence that shows two things are equal."
    },
    {
      "front": "Identity property",
      "back": "Adding 0 or multiplying by 1 keeps the number the same."
    },
    {
      "front": "Divisor",
      "back": "The number that divides another number."
    },
    {
      "front": "Divisible",
      "back": "Able to be divided evenly by a number."
    },
    {
      "front": "Factor",
      "back": "A number that divides evenly into another number."
    }
  ],
  [
    {
      "front": "Quotient",
      "back": "The result of division."
    },
    {
      "front": "Standard form",
      "back": "The usual way to write a number using digits."
    },
    {
      "front": "Digit",
      "back": "Any of the numbers 0 to 9."
    },
    {
      "front": "Place value",
      "back": "The value of a digit based on its position in a number."
    },
    {
      "front": "Hundredths",
      "back": "The second place value to the right of the decimal point."
    },
    {
      "front": "Rounding",
      "back": "Making a number simpler but keeping its value close."
    },
    {
      "front": "Word form",
      "back": "A number written using words."
    },
    {
      "front": "Compatible numbers",
      "back": "Numbers that are easy to compute mentally."
    },
    {
      "front": "Decimal",
      "back": "A number that includes a decimal point."
    },
    {
      "front": "Expanded form",
      "back": "A number shown as the sum of each digit multiplied by its place value."
    }
  ],
  [
    {
      "front": "Estimate",
      "back": "A close guess of the actual value."
    },
    {
      "front": "Tenths",
      "back": "The first place value to the right of the decimal point."
    },
    {
      "front": "tri- \u2013 three",
      "back": "triangle, tricycle"
    },
    {
      "front": "quad- \u2013 four",
      "back": "quadrilateral, quadrant"
    },
    {
      "front": "penta- \u2013 five",
      "back": "pentagon, pentathlon"
    },
    {
      "front": "hexa- \u2013 six",
      "back": "hexagon, hexapod"
    },
    {
      "front": "hepta- \u2013 seven",
      "back": "heptagon"
    },
    {
      "front": "octa- \u2013 eight",
      "back": "octagon, octopus"
    },
    {
      "front": "nona- \u2013 nine",
      "back": "nonagon"
    },
    {
      "front": "deca- \u2013 ten",
      "back": "decagon, decade"
    }
  ],
  [
    {
      "front": "centi- \u2013 hundredth",
      "back": "centimeter, centipede"
    },
    {
      "front": "milli- \u2013 thousandth",
      "back": "millimeter, milliliter"
    },
    {
      "front": "kilo- \u2013 thousand",
      "back": "kilometer, kilogram"
    },
    {
      "front": "poly- \u2013 many",
      "back": "polygon, polyhedron"
    },
    {
      "front": "mono- \u2013 one",
      "back": "monomial, monologue"
    },
    {
      "front": "bi- \u2013 two",
      "back": "bicycle, bimonthly"
    },
    {
      "front": "semi- \u2013 half / partly",
      "back": "semicircle, semiannual"
    },
    {
      "front": "equ- / equi- \u2013 equal",
      "back": "equilateral, equivalent"
    },
    {
      "front": "sym- / syn- \u2013 same / together",
      "back": "symmetry, synthesis"
    },
    {
      "front": "peri- \u2013 around",
      "back": "perimeter, periscope"
    }
  ],
  [
    {
      "front": "sub- \u2013 under / below",
      "back": "subzero, submarine"
    },
    {
      "front": "trans- \u2013 across / through",
      "back": "transform, translate"
    },
    {
      "front": "inter- \u2013 between",
      "back": "intersect, interconnect"
    },
    {
      "front": "pre- \u2013 before",
      "back": "predict, preview"
    },
    {
      "front": "re- \u2013 again / back",
      "back": "rewrite, return"
    },
    {
      "front": "co- / com- \u2013 with / together",
      "back": "combine, cooperate"
    },
    {
      "front": "-gon \u2013 angle / sides",
      "back": "hexagon, octagon, polygon"
    },
    {
      "front": "-meter \u2013 measure",
      "back": "thermometer, perimeter, speedometer"
    },
    {
      "front": "-metry \u2013 process of measuring",
      "back": "geometry, trigonometry"
    },
    {
      "front": "-graph \u2013 something written or drawn",
      "back": "autograph, paragraph, pictograph"
    }
  ],
  [
    {
      "front": "-gram \u2013 written result",
      "back": "diagram, telegram"
    },
    {
      "front": "-logy \u2013 study of",
      "back": "biology, geology, numerology"
    },
    {
      "front": "-nomy \u2013 system of rules / laws",
      "back": "astronomy, economy"
    },
    {
      "front": "-phobia \u2013 fear of",
      "back": "triskaidekaphobia"
    },
    {
      "front": "-hedron \u2013 solid shape",
      "back": "polyhedron, tetrahedron"
    },
    {
      "front": "-al \u2013 relating to",
      "back": "mathematical, symmetrical"
    },
    {
      "front": "-ic \u2013 having to do with",
      "back": "geometric, numeric"
    }
  ]
];